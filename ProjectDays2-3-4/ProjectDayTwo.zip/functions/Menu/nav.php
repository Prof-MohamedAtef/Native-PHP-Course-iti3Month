<ul>
<li><a href="login.php">Login</a></li>
  <li><a href="welcome.php">Welcome</a></li>
  <li><a href="services.php">Services</a></li>
  <li><a href="profile.php">Profile</a></li>
  <li><a href="logout.php">Logout</a></li>
</ul>