<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LoginSystem Login</title>
    <link rel="stylesheet" href="../Menu/MenuStyle/style.css">
</head>
<body style="background-image: url('redwood.jpg');background-size: 2100px 1800px">
<form method="post" action="welcome.php" >
    <label for="username">Username</label>
    <input type="text" id="username" name="username" placeholder="Enter username .."><br>
    <label for="password">Password</label>    
    <input type="password" id="password" name="password" placeholder="Enter password .."><br>
    <input type="submit" value="Submit">
</form>


</body>
</html>