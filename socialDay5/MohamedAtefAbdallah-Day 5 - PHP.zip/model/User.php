<?php

class User{

    public $ID;
    public $Name;
    public $Job;
    public $Image;
    public $Facebook;
    public $Twitter;
    public $Github;
    public $Articles;
    public $Followers;
    public $Rating;
}

?>